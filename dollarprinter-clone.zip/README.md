# DollarPrinter Clone

This is a clone of DollarPrinter.com with bot strategies, Deriv login, tutorials, and live logs.

## Features
- Deriv API token login
- Strategy cards (Over/Under, Even/Odd, Candle)
- Video tutorials
- Live signal placeholder
- Trade logs

## Setup
1. Run `npm install`
2. Start dev server with `npm run dev`

## Deploy
Use Vercel to deploy: https://vercel.com/import