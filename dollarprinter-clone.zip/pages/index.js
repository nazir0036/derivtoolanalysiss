
import React, { useState } from 'react';

export default function Home() {
  const [apiToken, setApiToken] = useState('');
  const [logs, setLogs] = useState([]);
  const strategies = [
    { name: 'Over/Under Bot', description: 'Trades based on digit over/under probability.' },
    { name: 'Even/Odd Bot', description: 'Trades based on even/odd analysis.' },
    { name: 'Candle Strategy', description: 'Uses candlestick patterns for signals.' },
  ];

  const runBot = (strategy) => {
    setLogs((prev) => [...prev, `Running ${strategy.name}...`]);
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>DollarPrinter Clone</h1>
      <input
        placeholder="Enter Deriv API Token"
        value={apiToken}
        onChange={(e) => setApiToken(e.target.value)}
      />
      <button onClick={() => alert('Token saved')}>Login</button>
      <h2>Strategies</h2>
      {strategies.map((s, i) => (
        <div key={i} style={{ border: '1px solid #ccc', padding: 10, marginBottom: 10 }}>
          <h3>{s.name}</h3>
          <p>{s.description}</p>
          <button onClick={() => runBot(s)}>Run Bot</button>
        </div>
      ))}
      <h2>Logs</h2>
      <ul>
        {logs.map((log, i) => <li key={i}>{log}</li>)}
      </ul>
    </div>
  );
}
